# ng-Wdatepicker



## How?

```html

<input class="Wdate" type="text" readOnly="true" wdate-picker ng-model="date1">

<script src="WdatePicker.js"></script>
<script src="angular.min.js"></script>
<script src="ng-WdatePicker.js"></script>
<script>
  var demoApp = angular.module('demoApp', ['ng-WdatePicker']);
</script>

```

## More

<a href="http://padding.me/ng-Wdatepicker/"> DEMO</a>


